
#define ENDFILE 255
